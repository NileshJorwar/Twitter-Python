## Assignment 0

**50 points**  


1. Get started with git and python by following the instructions at [Setup.md](Setup.md).
  
2. Complete the data collection assignment, following the instructions in [a0.py](a0.py).

3. Complete the short answer questions in [ShortAnswer.txt](ShortAnswer.txt).

3. Push your all your code and supporting files (e.g., .png) to your **private** GitHub repo in the folder `a0/`.
